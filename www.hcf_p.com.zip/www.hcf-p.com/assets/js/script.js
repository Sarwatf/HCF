$(document).ready(function() {
    $('#carouselExample').carousel({
        interval: 5000 // Change slide every 5 seconds
    });
});